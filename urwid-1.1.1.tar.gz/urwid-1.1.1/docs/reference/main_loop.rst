MainLoop and Event Loops
========================

.. currentmodule:: urwid

MainLoop
--------

.. autoclass:: MainLoop

SelectEventLoop
---------------

.. autoclass:: SelectEventLoop

GLibEventLoop
-------------

.. autoclass:: GLibEventLoop

TwistedEventLoop
----------------

.. autoclass:: TwistedEventLoop

