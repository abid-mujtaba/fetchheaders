Exceptions
==========

.. currentmodule:: urwid

.. autoexception:: ExitMainLoop

.. autoexception:: WidgetError

.. autoexception:: ListBoxError

.. autoexception:: ColumnsError

.. autoexception:: PileError

.. autoexception:: GridFlowError

.. autoexception:: BoxAdapterError

.. autoexception:: OverlayError

.. autoexception:: TextError

.. autoexception:: EditError

.. autoexception:: CanvasError
