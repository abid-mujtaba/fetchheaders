Text Layout Classes
===================

.. currentmodule:: urwid

.. autoclass:: TextLayout

.. autoclass:: StandardTextLayout
